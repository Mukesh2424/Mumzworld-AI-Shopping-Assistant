export interface Product {
  name: string;
  category: string;
  price: string;
  age_group: string;
  features: string[];
  description: string;
}

export type MessageRole = 'user' | 'assistant';

export interface Message {
  role: MessageRole;
  content: string;
  timestamp: number;
}
