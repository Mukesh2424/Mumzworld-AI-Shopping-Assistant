import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from "../data/products";
import { Message } from "../types";

const apiKey = process.env.GEMINI_API_KEY;

let ai: GoogleGenAI | null = null;

export function getGemini() {
  if (!ai) {
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing");
    }
    ai = new GoogleGenAI({ apiKey });
  }
  return ai;
}

const SYSTEM_INSTRUCTION = `
You are a smart AI shopping assistant for Mumzworld (Mumzworld AI Shopping Assistant). Your task is to recommend baby and mom products based ONLY on the provided dataset.

📦 DATASET:
${JSON.stringify(PRODUCTS, null, 2)}

🎯 OBJECTIVE:
Help users discover the most suitable products from our collection.

🧠 CORE CAPABILITIES:
1. Understand intent (age, budget, category, skin type).
2. Recommend the BEST 2–3 matching products.
3. Explain WHY each product is suitable with specific reasoning.
4. Apply filters (Price, Age group, Product type, Features).
5. REJECTION LOGIC: Briefly explain why other products were not selected (age mismatch, price, relevancy).

📋 RESPONSE FORMAT (STRICT):
1. Product Name:
   - Why it's suitable: (Directly connect to user need)
   - Key Features: (From dataset)

(Repeat for 2-3 products)

🔸 Why not other products?
(Briefly explain why others were rejected based on age, price, or features)

⚠️ RULES:
- Respond in English ONLY.
- Recommend ONLY from the provided dataset.
- Do NOT hallucinate products or brands.
- Limit to 2–3 products maximum.
- If no exact match exists, suggest the closest alternative from the data.
- Prioritize relevance (age group, use case) over popularity.
`;

export async function sendMessage(history: Message[], userInput: string): Promise<string> {
  const gemini = getGemini();
  
  // Format history for Gemini
  const contents = history.map(msg => ({
    role: msg.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: msg.content }]
  }));

  // Add the new user message
  contents.push({
    role: 'user',
    parts: [{ text: userInput }]
  });

  const response = await gemini.models.generateContent({
    model: "gemini-3-flash-preview",
    contents,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7,
    },
  });

  return response.text || "Sorry, I couldn't process your request.";
}
