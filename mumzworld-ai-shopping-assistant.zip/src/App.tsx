/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Baby, ShoppingBag, Info, Sparkles, MessageCircle, User } from 'lucide-react';
import { sendMessage } from './services/geminiService';
import { Message } from './types';

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Hello! I'm your Mumzworld smart assistant. How can I help you find the perfect products for you or your baby today?",
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await sendMessage(messages, input);
      const aiMessage: Message = {
        role: 'assistant',
        content: response,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        role: 'assistant',
        content: "I'm sorry, I encountered an error. Please try again later.",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen w-full bg-pink-50 overflow-hidden font-sans">
      {/* Header Navigation */}
      <header className="bg-white px-8 py-4 flex justify-between items-center border-b border-pink-100 shrink-0 z-10">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-pink-400 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-pink-200">M</div>
          <h1 className="text-2xl font-extrabold text-pink-600 tracking-tight">Mumzworld <span className="text-blue-400 font-bold">Shopping Assistant</span></h1>
        </div>
        <div className="flex items-center space-x-4">
          <span className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-semibold">Shopping Guide</span>
          <button className="text-gray-400 hover:text-pink-500 transition-colors">
            <Info className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Chat History / Sidebar */}
        <aside className="hidden md:flex w-80 bg-white/50 border-r border-pink-100 p-6 flex-col">
          <div className="mb-8">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Chat context</h3>
            <div className="p-4 bg-white rounded-2xl shadow-sm border border-pink-100">
              <p className="text-sm text-gray-700 italic">
                {messages.length > 1 
                  ? `"${messages[messages.length - 1].role === 'user' ? messages[messages.length - 1].content : messages[messages.length - 2].content}"`
                  : "Welcome to Mumzworld assistant."}
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Personalized Tags</h3>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-pink-200 text-pink-700 rounded-lg text-xs font-medium">Bestsellers</span>
              <span className="px-3 py-1 bg-blue-200 text-blue-700 rounded-lg text-xs font-medium">Tear-free</span>
              <span className="px-3 py-1 bg-green-200 text-green-700 rounded-lg text-xs font-medium">Verified</span>
            </div>
          </div>

          <div className="mt-auto flex flex-col items-center">
            <Baby className="w-12 h-12 text-pink-400 opacity-20 mb-3" />
            <p className="text-[10px] text-gray-400 text-center leading-relaxed">Your recommendations are based on our verified dermatologically tested catalog.</p>
          </div>
        </aside>

        {/* Results Content */}
        <section className="flex-1 p-4 md:p-8 overflow-hidden flex flex-col relative">
          <div className="flex items-center justify-between mb-6 px-2">
            <h2 className="text-xl font-bold text-gray-800">Shopping Stream</h2>
            <div className="flex items-center gap-2 text-xs text-pink-500 font-bold bg-white px-3 py-1.5 rounded-full shadow-sm border border-pink-50">
              <Sparkles className="w-3 h-3" />
              <span>Smart AI Assistant Active</span>
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 overflow-y-auto space-y-6 pb-24 scrollbar-hide px-2">
            <AnimatePresence initial={false}>
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} items-start gap-3`}
                >
                  {message.role === 'assistant' && (
                    <div className="w-10 h-10 rounded-2xl bg-pink-400 flex items-center justify-center text-white shrink-0 shadow-lg shadow-pink-100">
                      <Sparkles className="w-5 h-5" />
                    </div>
                  )}
                  
                  <div className={`max-w-[85%] md:max-w-[70%] ${message.role === 'user' ? 'chat-bubble-user' : 'chat-bubble-ai'}`}>
                    <div className="whitespace-pre-wrap text-sm leading-relaxed">
                      {message.content}
                    </div>
                    <div className={`text-[10px] mt-2 font-bold opacity-40 uppercase tracking-tighter ${message.role === 'user' ? 'text-right' : 'text-left'}`}>
                      {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  {message.role === 'user' && (
                    <div className="w-10 h-10 rounded-2xl bg-blue-400 flex items-center justify-center text-white shrink-0 shadow-lg shadow-blue-100">
                      <User className="w-5 h-5" />
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            
            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start items-center gap-3"
              >
                <div className="w-10 h-10 rounded-2xl bg-pink-400 flex items-center justify-center text-white shrink-0 shadow-lg">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </div>
                <div className="chat-bubble-ai px-5 py-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-pink-200 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-pink-200 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-pink-200 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Floating Input Bar */}
          <div className="absolute bottom-6 left-4 right-4 md:left-8 md:right-8">
            {messages.length === 1 && !input && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-center gap-3 mb-4 flex-wrap"
              >
                {['Baby Shampoo', 'Sensitive Skin', 'Lotion'].map((suggestion) => (
                  <button 
                    key={suggestion}
                    onClick={() => setInput(suggestion)}
                    className="bg-white/80 backdrop-blur-sm px-4 py-2 rounded-2xl text-xs font-bold text-gray-600 border border-pink-100 hover:border-pink-400 hover:text-pink-500 transition-all shadow-md active:scale-95"
                  >
                    {suggestion}
                  </button>
                ))}
              </motion.div>
            )}

            <div className="relative group">
              <div className="absolute inset-y-0 left-5 flex items-center">
                <MessageCircle className="w-5 h-5 text-pink-300 group-focus-within:text-pink-500 transition-colors" />
              </div>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about products, age groups, or budget..."
                className="w-full pl-14 pr-16 py-5 bg-white border border-pink-100 rounded-[2.5rem] shadow-2xl shadow-pink-200/40 focus:outline-none focus:ring-4 focus:ring-pink-100 focus:border-pink-300 transition-all placeholder:text-gray-300 font-medium"
              />
              <div className="absolute inset-y-0 right-3 flex items-center">
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="bg-pink-500 p-3 rounded-3xl text-white shadow-lg shadow-pink-500/30 hover:bg-pink-600 active:scale-90 disabled:opacity-30 disabled:hover:scale-100 transition-all"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
