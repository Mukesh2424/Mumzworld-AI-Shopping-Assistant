import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    "name": "Johnson's Baby Lotion",
    "category": "Skincare",
    "price": "₹250",
    "age_group": "0-2 years",
    "features": ["Gentle", "Hypoallergenic", "No parabens"],
    "description": "Softens baby's skin and prevents dryness"
  },
  {
    "name": "Himalaya Baby Shampoo",
    "category": "Haircare",
    "price": "₹180",
    "age_group": "0-5 years",
    "features": ["Tear-free", "Herbal", "Mild"],
    "description": "Cleans hair gently without irritation"
  },
  {
    "name": "Mamaearth Baby Wash",
    "category": "Skincare",
    "price": "₹399",
    "age_group": "0-5 years",
    "features": ["Soap-free", "Natural", "Tear-free"],
    "description": "Gently cleanses baby's skin without dryness"
  },
  {
    "name": "Sebamed Baby Cream",
    "category": "Skincare",
    "price": "₹450",
    "age_group": "0-3 years",
    "features": ["pH balanced", "Dermatologically tested", "Moisturizing"],
    "description": "Protects baby's delicate skin from dryness"
  },
  {
    "name": "Dabur Baby Massage Oil",
    "category": "Skincare",
    "price": "₹200",
    "age_group": "0-2 years",
    "features": ["Ayurvedic", "Nourishing", "Safe"],
    "description": "Strengthens baby's muscles and keeps skin soft"
  },
  {
    "name": "Chicco Baby Moments Shampoo",
    "category": "Haircare",
    "price": "₹320",
    "age_group": "0-5 years",
    "features": ["No tears", "Paraben-free", "Gentle"],
    "description": "Cleans baby's hair while being gentle on eyes"
  },
  {
    "name": "Pigeon Baby Wipes",
    "category": "Hygiene",
    "price": "₹150",
    "age_group": "0-3 years",
    "features": ["Alcohol-free", "Soft", "Moisturizing"],
    "description": "Keeps baby's skin clean and fresh"
  },
  {
    "name": "Mee Mee Baby Powder",
    "category": "Skincare",
    "price": "₹220",
    "age_group": "0-3 years",
    "features": ["Smooth", "Dermatologically tested", "Mild fragrance"],
    "description": "Keeps baby's skin dry and comfortable"
  }
];
